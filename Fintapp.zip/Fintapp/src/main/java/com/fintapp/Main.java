package com.fintapp;

import java.io.File;
import java.io.IOException;

import com.fintapp.controllers.SceneController;

import javafx.application.Application;
import javafx.stage.Stage;

import com.fintapp.models.User;
import com.fintapp.services.UserService;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        createDataFolder();
        SceneController.setStages();
        UserService userService = new UserService();
        User currentUser = userService.getCurrentUser();
        if (currentUser != null)
            SceneController.showMainStage();
        else
            SceneController.showAuthenticationStage();
    }

    private static void createDataFolder() {
        File dataFolder = new File(AppPaths.DATA_ROOT);
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }

}
