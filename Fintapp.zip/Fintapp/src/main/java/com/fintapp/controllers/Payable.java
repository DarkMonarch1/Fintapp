package com.fintapp.controllers;

public interface Payable {
  public void processOutgoingTransaction();
}
