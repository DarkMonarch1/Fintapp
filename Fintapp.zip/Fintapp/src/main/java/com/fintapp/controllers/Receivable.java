package com.fintapp.controllers;

public interface Receivable {
  public void processIncomingTransaction();
  
}
