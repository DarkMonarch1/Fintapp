package com.fintapp.controllers;

import com.fintapp.models.TransactionLimit;
import com.fintapp.models.User;
import com.fintapp.services.TransactionService;
import com.fintapp.services.UserService;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class TransactionLimits {

    @FXML
    private Label addMoneySpentLabel,
            sendMoneySpentLabel,
            mobileTopUpSpentLabel,
            fintappToBankSpentLabel,
            withdrawCashSpentLabel,
            addMoneyRemainingLabel,
            sendMoneyRemainingLabel,
            mobileTopUpRemainingLabel,
            fintappToBankRemainingLabel,
            withdrawCashRemainingLabel;

    @FXML
    private ProgressBar addMoneyProgressBar,
            sendMoneyProgressBar,
            mobileTopUpProgressBar,
            fintappToBankProgressBar,
            withdrawCashProgressBar;

    @FXML
    private void initialize() {
        User currentUser = new UserService().getCurrentUser();
        TransactionService transactionService = new TransactionService();

        double addMoneySpent = transactionService.getSpentAmount(currentUser, "Add Money");
        double sendMoneySpent = transactionService.getSpentAmount(currentUser, "Send Money");
        double mobileTopUpSpent = transactionService.getSpentAmount(currentUser, "Mobile Top-up");
        double fintappToBankSpent = transactionService.getSpentAmount(currentUser, "Fintapp to Bank");
        double withdrawCashSpent = transactionService.getSpentAmount(currentUser, "Withdraw Cash");

        double addMoneyRemaining = TransactionLimit.ADD_MONEY.getLimit() - addMoneySpent;
        double sendMoneyRemaining = TransactionLimit.SEND_MONEY.getLimit() - sendMoneySpent;
        double mobileTopUpRemaining = TransactionLimit.MOBILE_TOP_UP.getLimit() - mobileTopUpSpent;
        double fintappToBankRemaining = TransactionLimit.FINTAPP_TO_BANK.getLimit() - fintappToBankSpent;
        double withdrawCashRemaining = TransactionLimit.WITHDRAW_CASH.getLimit() - withdrawCashSpent;

        addMoneySpentLabel.setText(String.format("%.2f", addMoneySpent));
        sendMoneySpentLabel.setText(String.format("%.2f", sendMoneySpent));
        mobileTopUpSpentLabel.setText(String.format("%.2f", mobileTopUpSpent));
        fintappToBankSpentLabel.setText(String.format("%.2f", fintappToBankSpent));
        withdrawCashSpentLabel.setText(String.format("%.2f", withdrawCashSpent));

        addMoneyRemainingLabel.setText(String.format("%.2f", addMoneyRemaining));
        sendMoneyRemainingLabel.setText(String.format("%.2f", sendMoneyRemaining));
        mobileTopUpRemainingLabel.setText(String.format("%.2f", mobileTopUpRemaining));
        fintappToBankRemainingLabel.setText(String.format("%.2f", fintappToBankRemaining));
        withdrawCashRemainingLabel.setText(String.format("%.2f", withdrawCashRemaining));

        addMoneyProgressBar.setProgress(addMoneySpent / TransactionLimit.ADD_MONEY.getLimit());
        sendMoneyProgressBar.setProgress(sendMoneySpent / TransactionLimit.SEND_MONEY.getLimit());
        mobileTopUpProgressBar.setProgress(mobileTopUpSpent / TransactionLimit.MOBILE_TOP_UP.getLimit());
        fintappToBankProgressBar.setProgress(fintappToBankSpent / TransactionLimit.FINTAPP_TO_BANK.getLimit());
        withdrawCashProgressBar.setProgress(withdrawCashSpent / TransactionLimit.WITHDRAW_CASH.getLimit());
    }
}
