package com.fintapp;

import java.io.File;

public final class AppPaths {
    private AppPaths() {
    }

    public static final String DATA_ROOT =
            System.getProperty("user.home") + File.separator + "Fintapp" + File.separator + "data";

    public static File dataFile(String name) {
        return new File(DATA_ROOT, name);
    }
}
