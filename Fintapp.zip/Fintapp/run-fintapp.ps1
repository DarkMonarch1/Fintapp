Set-Location $PSScriptRoot
mvn org.openjfx:javafx-maven-plugin:0.0.8:run
